function memoize(fn) {
    const cache = {}; // Приватный кэш

    return function(...args) {
        const key = JSON.stringify(args); // Создаем ключ из аргументов

        if (key in cache) {
            console.log("Returning cached result for", args);
            return cache[key];
        } else {
            console.log("Calculating result for", args);
            const result = fn(...args);
            cache[key] = result;
            return result;
        }
    };
}

// Пример использования:
function expensiveCalculation(n) {
    console.log("Calculating for", n);
    return n * 2;
}

const memoizedCalculation = memoize(expensiveCalculation);

console.log(memoizedCalculation(5)); // "Calculating for 5", 10
console.log(memoizedCalculation(5)); // "Returning cached result for [5]", 10
console.log(memoizedCalculation(10)); // "Calculating for 10", 20
console.log(memoizedCalculation(10)); // "Returning cached result for [10]", 20