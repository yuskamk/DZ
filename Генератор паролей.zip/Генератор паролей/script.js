/**
 * Генератор паролей
 * Упрощённая версия без надёжности и советов
 */

// Главная функция для создания пароля
function generatePassword(length, options) {
    // Проверяем, что длина нормальная
    if (length < 4) {
        throw new Error('Пароль слишком короткий! Минимум 4 символа');
    }
    
    // Если options не передали, используем значения по умолчанию
    if (!options) {
        options = {
            uppercase: true,
            lowercase: true,
            numbers: true,
            symbols: true
        };
    }
    
    // Проверяем, что хоть что-то выбрано
    if (!options.uppercase && !options.lowercase && !options.numbers && !options.symbols) {
        throw new Error('Выбери хоть один тип символов!');
    }
    
    // Все возможные символы
    const bigLetters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    const smallLetters = 'abcdefghijklmnopqrstuvwxyz';
    const digits = '0123456789';
    const special = '!@#$%^&*()_+-=[]{}|;:,.<>?';
    
    // Собираем все символы, которые будем использовать
    let allChars = '';
    if (options.uppercase) allChars += bigLetters;
    if (options.lowercase) allChars += smallLetters;
    if (options.numbers) allChars += digits;
    if (options.symbols) allChars += special;
    
    // Начинаем собирать пароль
    let password = '';
    
    // Сначала добавляем по одному символу из каждого выбранного типа
    if (options.uppercase) {
        password += bigLetters[Math.floor(Math.random() * bigLetters.length)];
    }
    if (options.lowercase) {
        password += smallLetters[Math.floor(Math.random() * smallLetters.length)];
    }
    if (options.numbers) {
        password += digits[Math.floor(Math.random() * digits.length)];
    }
    if (options.symbols) {
        password += special[Math.floor(Math.random() * special.length)];
    }
    
    // Добавляем остальные символы до нужной длины
    for (let i = password.length; i < length; i++) {
        password += allChars[Math.floor(Math.random() * allChars.length)];
    }
    
    // Перемешиваем символы
    password = password.split('').sort(() => Math.random() - 0.5).join('');
    
    return password;
}

// Функция для обновления цифры рядом со слайдером
function updateLengthDisplay() {
    const slider = document.getElementById('passwordLength');
    const valueSpan = document.getElementById('lengthValue');
    valueSpan.textContent = slider.value;
}

// Главная функция, которая генерирует и показывает пароль
function generateAndShowPassword() {
    try {
        // Получаем настройки из формы
        const length = parseInt(document.getElementById('passwordLength').value);
        const uppercase = document.getElementById('uppercase').checked;
        const lowercase = document.getElementById('lowercase').checked;
        const numbers = document.getElementById('numbers').checked;
        const symbols = document.getElementById('symbols').checked;
        
        // Создаём пароль
        const password = generatePassword(length, {
            uppercase, lowercase, numbers, symbols
        });
        
        // Показываем пароль на странице
        document.getElementById('passwordDisplay').textContent = password;
        
        // Показываем блок с результатом
        document.getElementById('result').style.display = 'block';
        
    } catch (error) {
        // Если что-то пошло не так, показываем ошибку
        alert('Ошибка: ' + error.message);
    }
}

// Функция для копирования пароля
function copyPassword() {
    const passwordText = document.getElementById('passwordDisplay').textContent;
    
    // Пробуем скопировать современным способом
    if (navigator.clipboard) {
        navigator.clipboard.writeText(passwordText)
            .then(() => {
                showMessage('Пароль скопирован!');
            })
            .catch(() => {
                // Если не получилось, используем старый способ
                copyOldWay(passwordText);
            });
    } else {
        // Старый способ для старых браузеров
        copyOldWay(passwordText);
    }
}

// Старый способ копирования
function copyOldWay(text) {
    // Создаём невидимое текстовое поле
    const textArea = document.createElement('textarea');
    textArea.value = text;
    document.body.appendChild(textArea);
    
    // Выделяем текст и копируем
    textArea.select();
    try {
        document.execCommand('copy');
        showMessage('Пароль скопирован!');
    } catch (err) {
        showMessage('Не получилось скопировать :(');
    }
    
    // Убираем текстовое поле
    document.body.removeChild(textArea);
}

// Функция для показа сообщения
function showMessage(text) {
    // Создаём элемент для сообщения
    const message = document.createElement('div');
    message.textContent = text;
    message.style.cssText = `
        position: fixed;
        top: 20px;
        left: 50%;
        transform: translateX(-50%);
        background: #4a6fa5;
        color: white;
        padding: 10px 20px;
        border-radius: 5px;
        z-index: 1000;
        font-weight: bold;
    `;
    
    // Добавляем на страницу
    document.body.appendChild(message);
    
    // Убираем через 2 секунды
    setTimeout(() => {
        document.body.removeChild(message);
    }, 2000);
}

// Всё что нужно сделать когда страница загрузится
function init() {
    // Обновляем цифру длины при загрузке
    updateLengthDisplay();
    
    // Настраиваем слайдер
    document.getElementById('passwordLength').addEventListener('input', updateLengthDisplay);
    
    // Настраиваем кнопку генерации
    document.getElementById('generateBtn').addEventListener('click', generateAndShowPassword);
    
    // Настраиваем кнопку копирования
    document.getElementById('copyBtn').addEventListener('click', copyPassword);
    
    // Сразу генерируем первый пароль
    generateAndShowPassword();
    
    console.log('Генератор паролей готов к работе!');
}

// Запускаем когда страница полностью загрузится
document.addEventListener('DOMContentLoaded', init);