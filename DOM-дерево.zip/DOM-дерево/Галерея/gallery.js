// Находим все нужные элементы на странице
const gallery = document.getElementById('gallery'); // Контейнер с миниатюрами
const overlay = document.getElementById('overlay'); // Затемненный фон
const fullsizeImage = document.getElementById('fullsizeImage'); // Большое изображение
const closeBtn = document.getElementById('closeBtn'); // Кнопка закрытия
const prevBtn = document.getElementById('prevBtn'); // Кнопка "назад"
const nextBtn = document.getElementById('nextBtn'); // Кнопка "вперед"
const imageCounter = document.getElementById('imageCounter'); // Счетчик

// Переменные для хранения текущего состояния
let currentImageIndex = 0; // Индекс текущего изображения
let images = []; // Массив всех изображений

// Собираем все изображения из галереи в массив
function initGallery() {
    images = Array.from(gallery.querySelectorAll('img'));
    console.log('Найдено изображений:', images.length);
}

// Открываем полноразмерное изображение
function openFullsize(index) {
    // Получаем ссылку на большое изображение из data-атрибута
    const imageSrc = images[index].getAttribute('data-fullsize');
    
    // Устанавливаем большое изображение
    fullsizeImage.src = imageSrc;
    fullsizeImage.alt = images[index].alt;
    
    // Сохраняем текущий индекс
    currentImageIndex = index;
    
    // Показываем оверлей (убираем класс hidden)
    overlay.classList.remove('hidden');
    
    // Обновляем счетчик
    updateCounter();
    
    // Прячем/показываем кнопки навигации, если изображение первое/последнее
    updateNavButtons();
}

// Закрываем полноразмерное изображение
function closeFullsize() {
    // Прячем оверлей (добавляем класс hidden)
    overlay.classList.add('hidden');
}

// Переходим к следующему изображению
function nextImage() {
    // Если текущее изображение не последнее, увеличиваем индекс
    if (currentImageIndex < images.length - 1) {
        currentImageIndex++;
        openFullsize(currentImageIndex);
    }
}

// Переходим к предыдущему изображению
function prevImage() {
    // Если текущее изображение не первое, уменьшаем индекс
    if (currentImageIndex > 0) {
        currentImageIndex--;
        openFullsize(currentImageIndex);
    }
}

// Обновляем счетчик изображений
function updateCounter() {
    imageCounter.textContent = `${currentImageIndex + 1} / ${images.length}`;
}

// Обновляем состояние кнопок навигации
function updateNavButtons() {
    // Прячем кнопку "назад", если это первое изображение
    prevBtn.style.display = currentImageIndex === 0 ? 'none' : 'block';
    
    // Прячем кнопку "вперед", если это последнее изображение
    nextBtn.style.display = currentImageIndex === images.length - 1 ? 'none' : 'block';
}

// Обработчики событий

// Делегирование событий: слушаем клики по галерее
gallery.addEventListener('click', function(event) {
    // Проверяем, кликнули ли именно на изображение
    if (event.target.tagName === 'IMG') {
        // Находим индекс кликнутого изображения
        const clickedIndex = images.indexOf(event.target);
        
        // Если нашли индекс, открываем изображение
        if (clickedIndex !== -1) {
            openFullsize(clickedIndex);
        }
    }
});

// Закрытие по кнопке
closeBtn.addEventListener('click', closeFullsize);

// Закрытие по клику на затемненную область (но не на само изображение)
overlay.addEventListener('click', function(event) {
    // Если кликнули именно на оверлей (фон), а не на контент
    if (event.target === overlay) {
        closeFullsize();
    }
});

// Навигация по кнопкам
nextBtn.addEventListener('click', nextImage);
prevBtn.addEventListener('click', prevImage);

// Навигация с помощью клавиатуры
document.addEventListener('keydown', function(event) {
    // Если открыто полноразмерное изображение
    if (!overlay.classList.contains('hidden')) {
        // Стрелка вправо или пробел - следующее изображение
        if (event.key === 'ArrowRight' || event.key === ' ') {
            event.preventDefault(); // Отменяем прокрутку страницы пробелом
            nextImage();
        }
        // Стрелка влево - предыдущее изображение
        else if (event.key === 'ArrowLeft') {
            prevImage();
        }
        // Escape - закрыть просмотр
        else if (event.key === 'Escape') {
            closeFullsize();
        }
    }
});

// Инициализируем галерею при загрузке страницы
document.addEventListener('DOMContentLoaded', initGallery);