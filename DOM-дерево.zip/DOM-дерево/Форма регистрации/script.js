// Находим все нужные элементы на странице
const form = document.getElementById('register-form');
const nameInput = document.getElementById('name');
const emailInput = document.getElementById('email');
const passwordInput = document.getElementById('password');
const confirmPasswordInput = document.getElementById('confirm-password');
const submitBtn = document.getElementById('submit-btn');
const successMessage = document.getElementById('success-message');

// Находим элементы для отображения ошибок
const nameError = document.getElementById('name-error');
const emailError = document.getElementById('email-error');
const passwordError = document.getElementById('password-error');
const confirmPasswordError = document.getElementById('confirm-password-error');

// Функция для проверки имени
function validateName() {
    // Получаем значение из поля и убираем лишние пробелы
    const name = nameInput.value.trim();
    
    // Проверяем длину имени (минимум 2 символа)
    if (name.length < 2) {
        showError(nameInput, nameError, 'Имя должно содержать минимум 2 символа');
        return false;
    }
    
    // Проверяем, что имя содержит только буквы (русские и английские)
    const nameRegex = /^[a-zA-Zа-яА-ЯёЁ\s]+$/;
    if (!nameRegex.test(name)) {
        showError(nameInput, nameError, 'Имя может содержать только буквы');
        return false;
    }
    
    // Если все проверки пройдены, убираем ошибку
    showSuccess(nameInput, nameError);
    return true;
}

// Функция для проверки email
function validateEmail() {
    const email = emailInput.value.trim();
    
    // Проверяем, что поле не пустое
    if (email === '') {
        showError(emailInput, emailError, 'Email обязателен для заполнения');
        return false;
    }
    
    // Проверяем формат email с помощью регулярного выражения
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        showError(emailInput, emailError, 'Введите корректный email адрес');
        return false;
    }
    
    showSuccess(emailInput, emailError);
    return true;
}

// Функция для проверки пароля
function validatePassword() {
    const password = passwordInput.value;
    
    // Проверяем длину пароля
    if (password.length < 8) {
        showError(passwordInput, passwordError, 'Пароль должен содержать минимум 8 символов');
        return false;
    }
    
    // Проверяем наличие заглавной буквы
    if (!/[A-Z]/.test(password)) {
        showError(passwordInput, passwordError, 'Пароль должен содержать хотя бы одну заглавную букву');
        return false;
    }
    
    // Проверяем наличие цифры
    if (!/\d/.test(password)) {
        showError(passwordInput, passwordError, 'Пароль должен содержать хотя бы одну цифру');
        return false;
    }
    
    showSuccess(passwordInput, passwordError);
    return true;
}

// Функция для проверки подтверждения пароля
function validateConfirmPassword() {
    const password = passwordInput.value;
    const confirmPassword = confirmPasswordInput.value;
    
    // Проверяем, что пароли совпадают
    if (password !== confirmPassword) {
        showError(confirmPasswordInput, confirmPasswordError, 'Пароли не совпадают');
        return false;
    }
    
    // Проверяем, что поле подтверждения не пустое
    if (confirmPassword === '') {
        showError(confirmPasswordInput, confirmPasswordError, 'Подтвердите пароль');
        return false;
    }
    
    showSuccess(confirmPasswordInput, confirmPasswordError);
    return true;
}

// Функция для показа ошибки
function showError(inputElement, errorElement, message) {
    // Добавляем красную рамку полю
    inputElement.classList.add('invalid');
    inputElement.classList.remove('valid');
    
    // Показываем сообщение об ошибке
    errorElement.textContent = message;
}

// Функция для показа успешной валидации
function showSuccess(inputElement, errorElement) {
    // Добавляем зеленую рамку полю
    inputElement.classList.add('valid');
    inputElement.classList.remove('invalid');
    
    // Очищаем сообщение об ошибке
    errorElement.textContent = '';
}

// Функция для проверки всей формы
function validateForm() {
    // Проверяем все поля и сохраняем результаты
    const isNameValid = validateName();
    const isEmailValid = validateEmail();
    const isPasswordValid = validatePassword();
    const isConfirmPasswordValid = validateConfirmPassword();
    
    // Если все проверки пройдены, форма валидна
    return isNameValid && isEmailValid && isPasswordValid && isConfirmPasswordValid;
}

// Функция для сброса формы
function resetForm() {
    form.reset();
    
    // Убираем все стили валидации
    const allInputs = [nameInput, emailInput, passwordInput, confirmPasswordInput];
    const allErrors = [nameError, emailError, passwordError, confirmPasswordError];
    
    allInputs.forEach(input => {
        input.classList.remove('valid', 'invalid');
    });
    
    allErrors.forEach(error => {
        error.textContent = '';
    });
}

// Назначаем обработчики событий для валидации в реальном времени

// Для имени - проверяем при каждом вводе символа
nameInput.addEventListener('input', validateName);

// Для email - проверяем при каждом вводе
emailInput.addEventListener('input', validateEmail);

// Для пароля - проверяем при каждом вводе
passwordInput.addEventListener('input', function() {
    validatePassword();
    // Также проверяем подтверждение пароля, когда меняется основной пароль
    validateConfirmPassword();
});

// Для подтверждения пароля - проверяем при каждом вводе
confirmPasswordInput.addEventListener('input', validateConfirmPassword);

// Обработчик отправки формы
form.addEventListener('submit', function(event) {
    // Предотвращаем стандартную отправку формы
    event.preventDefault();
    
    // Проверяем всю форму
    if (validateForm()) {
        // Если форма валидна, показываем сообщение об успехе
        successMessage.classList.remove('hidden');
        
        // Через 3 секунды скрываем сообщение и сбрасываем форму
        setTimeout(function() {
            successMessage.classList.add('hidden');
            resetForm();
        }, 3000);
        
        // В реальном приложении здесь был бы AJAX-запрос на сервер
        console.log('Форма валидна, отправляем данные на сервер...');
        console.log('Имя:', nameInput.value.trim());
        console.log('Email:', emailInput.value.trim());
    } else {
        // Если форма невалидна, показываем общую ошибку
        alert('Пожалуйста, исправьте ошибки в форме');
    }
});

// Дополнительная валидация при потере фокуса полем (когда пользователь уходит с поля)
nameInput.addEventListener('blur', validateName);
emailInput.addEventListener('blur', validateEmail);
passwordInput.addEventListener('blur', validatePassword);
confirmPasswordInput.addEventListener('blur', validateConfirmPassword);