// Находим все нужные элементы на странице
const openModalBtn = document.getElementById('openModalBtn');    // Кнопка открытия
const closeModalBtn = document.getElementById('closeModalBtn');  // Кнопка закрытия
const modalOverlay = document.getElementById('modalOverlay');    // Фон модального окна
const modalContent = document.getElementById('modalContent');    // Само модальное окно

// Функция для открытия модального окна
function openModal() {
    console.log('Открываем модальное окно');
    
    // Добавляем класс 'active' чтобы показать окно
    modalOverlay.classList.add('active');
    
    // Блокируем прокрутку страницы когда окно открыто
    document.body.style.overflow = 'hidden';
}

// Функция для закрытия модального окна
function closeModal() {
    console.log('Закрываем модальное окно');
    
    // Убираем класс 'active' чтобы скрыть окно
    modalOverlay.classList.remove('active');
    
    // Разблокируем прокрутку страницы
    document.body.style.overflow = 'auto';
}

// Открываем окно при клике на кнопку
openModalBtn.addEventListener('click', openModal);

// Закрываем окно при клике на кнопку "Закрыть"
closeModalBtn.addEventListener('click', closeModal);

// Закрываем окно при клике на затемненную область вокруг него
modalOverlay.addEventListener('click', function(event) {
    // Проверяем, был ли клик именно на фоне (а не на самом окне)
    if (event.target === modalOverlay) {
        closeModal();
    }
});

// Закрываем окно при нажатии клавиши Escape на клавиатуре
document.addEventListener('keydown', function(event) {
    // Проверяем, нажата ли клавиша Escape и открыто ли окно
    if (event.key === 'Escape' && modalOverlay.classList.contains('active')) {
        closeModal();
    }
});

// Предотвращаем закрытие окна при клике на само окно
modalContent.addEventListener('click', function(event) {
    // Останавливаем всплытие события, чтобы клик на окне не дошел до фона
    event.stopPropagation();
});

// Просто сообщение в консоль что скрипт загрузился
console.log('Скрипт модального окна загружен и готов к работе');